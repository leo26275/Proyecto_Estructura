function validar() {

// El objeto document es el que tiene el contenido de toda la página que se está visualizando.  

    /* El método getElementById permite, como su nombre indica, seleccionar
     un elemento del documento por medio del valor del atributo id
     que se le haya asignado. Su sintaxis es la siguiente: 
     document.getElementById('id_del_elemento'); */


    var idgranja = document.getElementById("id").value;
    var nombregranja = document.getElementById("nombre").value;
    var tipogranja = document.getElementById("tipo").value;
    var direccion = document.getElementById("direccion").value;
    var idmunicipio = document.getElementById("idmunicipio").value;
    var fechacreaciongranja = document.getElementById("fecha").value;
    var capacidad = document.getElementById("capacidad").value;
    var valorgranja = document.getElementById("valor").value;

     // || estadoCivilEmpleado == "" || sexoEmpleado == "" || activo == false

    var activa = document.getElementById("rbEstado").value;
     if (document.getElementsByTagName('rbEstado')[0] || document.getElementsByTagName('rbEstado')[1]){
         
         
     }

    if (idgranja == "" || nombregranja == "" || tipogranja == "" || direccion == "" || idmunicipio == "") 
    {
        alert("Por favor complete el formulario");
        return 0;
    }
    else
    {
        document.frmGranja.submit();
    }

}